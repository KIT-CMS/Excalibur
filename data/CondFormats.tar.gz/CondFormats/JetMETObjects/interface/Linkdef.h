#ifdef __CINT__
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#pragma link C++ nestedclasses;

#pragma link C++ class JetCorrectorParameters+;
#pragma link C++ class JetCorrectorParameters::Definitions+;
#pragma link C++ class JetCorrectorParameters::Record+;
#pragma link C++ class SimpleJetCorrector+;
#pragma link C++ class FactorizedJetCorrector+;
#endif // __CINT__
